// Nexra Vegetable Shop POS - backend (Node 22.13+, no npm packages needed)
const http = require("http"), fs = require("fs"), path = require("path"), crypto = require("crypto");
const { DatabaseSync } = require("node:sqlite");
const PORT = process.env.PORT || 3000;
const DB_FILE = process.env.DB_PATH || path.join(__dirname, "nexra.db");
const db = new DatabaseSync(DB_FILE);
db.exec(`PRAGMA journal_mode=WAL;
create table if not exists users(name text primary key, role text not null, salt text not null, hash text not null);
create table if not exists products(id text primary key, en text, si text, ta text, cat text, unit text, price real, cost real, stock real, low real, active integer default 1, img text default '');
create table if not exists sales(id text primary key, no integer unique, at text, pay text, rec real, sub real, disc real, total real, user text, items text);
create table if not exists audit(id integer primary key autoincrement, at text, user text, action text, detail text);
create table if not exists meta(k text primary key, v text);`);

const hashPin = (pin, salt) => crypto.scryptSync(String(pin), salt, 32).toString("hex");
const round2 = x => Math.round(x * 100) / 100;
const audit = (user, action, detail) => db.prepare("insert into audit(at,user,action,detail) values(?,?,?,?)").run(new Date().toISOString(), user, action, detail);
class HttpError extends Error { constructor(s, m) { super(m); this.status = s; } }
const err = (s, m) => new HttpError(s, m);

// ---- first-run setup ----
let secret = db.prepare("select v from meta where k='secret'").get()?.v;
if (!secret) { secret = crypto.randomBytes(32).toString("hex"); db.prepare("insert into meta values('secret',?)").run(secret); }
if (!db.prepare("select count(*) c from users").get().c) {
  for (const [n, r, p] of [["Owner", "owner", "1111"], ["Manager", "manager", "2222"], ["Cashier", "cashier", "3333"]]) {
    const salt = crypto.randomBytes(16).toString("hex");
    db.prepare("insert into users values(?,?,?,?)").run(n, r, salt, hashPin(p, salt));
  }
  console.log("Created default users. Change the PINs after the first login!");
}
if (!db.prepare("select count(*) c from products").get().c) {
  const ins = db.prepare("insert into products(id,en,si,ta,cat,unit,price,cost,stock,low) values(?,?,?,?,?,?,?,?,?,5)");
  for (const p of JSON.parse(fs.readFileSync(path.join(__dirname, "seed-products.json"), "utf8")))
    ins.run(p.id, p.en, p.si, p.ta, p.cat, p.unit, p.price, p.cost, p.stock);
}

// ---- tokens & login throttling ----
const sign = s => crypto.createHmac("sha256", secret).update(s).digest("base64url");
const makeToken = u => { const b = Buffer.from(JSON.stringify({ n: u.name, role: u.role, exp: Date.now() + 12 * 3600e3 })).toString("base64url"); return b + "." + sign(b); };
function auth(req) {
  const [b, s] = (req.headers.authorization || "").replace("Bearer ", "").split(".");
  if (!b || !s || sign(b).length !== s.length || !crypto.timingSafeEqual(Buffer.from(sign(b)), Buffer.from(s))) throw err(401, "Please log in again");
  const d = JSON.parse(Buffer.from(b, "base64url"));
  if (d.exp < Date.now()) throw err(401, "Session expired. Please log in again");
  if (!db.prepare("select 1 from users where name=?").get(d.n)) throw err(401, "User no longer exists");
  return d;
}
const fails = new Map();
function checkLock(k) { const f = fails.get(k); if (f && f.n >= 5 && Date.now() < f.until) throw err(429, "Too many wrong PINs. Wait 5 minutes."); }
function noteFail(k) { const f = fails.get(k) || { n: 0 }; f.n++; f.until = Date.now() + 300e3; fails.set(k, f); }

// ---- data helpers ----
const prodOut = (r, role) => ({ id: r.id, en: r.en, si: r.si, ta: r.ta, cat: r.cat, unit: r.unit, price: r.price, cost: role === "cashier" ? 0 : r.cost, stock: r.stock, low: r.low, on: !!r.active, img: r.img || "" });
const saleOut = (r, role) => { const s = { ...r, items: JSON.parse(r.items) }; if (role === "cashier") s.items = s.items.map(i => ({ ...i, cost: 0 })); return s; };
const allProducts = role => db.prepare("select * from products order by id").all().map(r => prodOut(r, role));

function saveProduct(oldId, b, user) {
  const p = {
    id: String(b.id || "").trim(), en: String(b.en || "").trim(), si: String(b.si || ""), ta: String(b.ta || ""),
    cat: String(b.cat || "Vegetable"), unit: String(b.unit || "kg"), price: +b.price, cost: +b.cost || 0, stock: +b.stock, low: +b.low || 0,
    active: b.on ? 1 : 0, img: String(b.img || "")
  };
  if (!/^[A-Za-z0-9_-]{1,20}$/.test(p.id)) throw err(400, "Product code must be letters, numbers, - or _");
  if (!p.en) throw err(400, "English name is required");
  if (!(p.price > 0)) throw err(400, "Selling price must be above 0");
  if (!(p.stock >= 0)) throw err(400, "Stock cannot be negative");
  if (!["kg", "piece", "bunch", "bundle", "packet"].includes(p.unit)) throw err(400, "Unknown unit");
  if (p.img && (!p.img.startsWith("data:image/") || p.img.length > 500000)) throw err(400, "Photo is too large");
  const old = db.prepare("select * from products where id=?").get(oldId);
  if (old && oldId !== p.id) {
    if (db.prepare("select 1 from products where id=?").get(p.id)) throw err(400, "That code is already used");
    db.prepare("update products set id=? where id=?").run(p.id, oldId);
  } else if (!old && db.prepare("select 1 from products where id=?").get(p.id)) throw err(400, "That code is already used");
  if (old || db.prepare("select 1 from products where id=?").get(p.id)) {
    const was = db.prepare("select * from products where id=?").get(p.id);
    db.prepare("update products set en=?,si=?,ta=?,cat=?,unit=?,price=?,cost=?,stock=?,low=?,active=?,img=? where id=?")
      .run(p.en, p.si, p.ta, p.cat, p.unit, p.price, p.cost, p.stock, p.low, p.active, p.img, p.id);
    if (was.price !== p.price) audit(user, "price", `${p.id}: ${was.price} -> ${p.price}`);
    if (was.stock !== p.stock) audit(user, "stock", `${p.id}: ${was.stock} -> ${p.stock}`);
    audit(user, "product-edit", p.id);
  } else {
    db.prepare("insert into products(id,en,si,ta,cat,unit,price,cost,stock,low,active,img) values(?,?,?,?,?,?,?,?,?,?,?,?)")
      .run(p.id, p.en, p.si, p.ta, p.cat, p.unit, p.price, p.cost, p.stock, p.low, p.active, p.img);
    audit(user, "product-add", p.id);
  }
}

function createSale(b, user, role) {
  const dup = db.prepare("select * from sales where id=?").get(b.id);
  if (dup) return saleOut(dup, role); // same request retried: never create a second sale
  if (!b.id || String(b.id).length > 60) throw err(400, "Missing sale id");
  if (!["cash", "card", "bank"].includes(b.pay)) throw err(400, "Choose a payment method");
  if (!Array.isArray(b.items) || !b.items.length) throw err(400, "Cart is empty");
  db.exec("BEGIN IMMEDIATE");
  try {
    let sub = 0; const items = [];
    for (const it of b.items) {
      const p = db.prepare("select * from products where id=? and active=1").get(it.id);
      if (!p) throw err(400, "Product not available: " + it.id);
      const q = +it.q; if (!(q > 0)) throw err(400, "Enter a quantity for " + p.en);
      const u = it.u === "g" && p.unit === "kg" ? "g" : p.unit, base = q * (u === "g" ? 0.001 : 1);
      if (base > p.stock + 1e-9) throw err(400, "Not enough " + p.en + " in stock");
      const line = round2(p.price * base); sub += line;
      db.prepare("update products set stock=round(stock-?,3) where id=?").run(base, p.id);
      items.push({ id: p.id, name: p.en, q, u, price: p.price, cost: p.cost, base, line });
    }
    sub = round2(sub);
    const disc = Math.min(sub, Math.max(0, +b.disc || 0)), total = round2(sub - disc), rec = +b.rec || 0;
    if (b.pay === "cash" && rec < total) throw err(400, "Cash received is less than the total");
    const no = db.prepare("select coalesce(max(no),1000)+1 n from sales").get().n, at = new Date().toISOString();
    db.prepare("insert into sales values(?,?,?,?,?,?,?,?,?,?)").run(b.id, no, at, b.pay, rec, sub, disc, total, user, JSON.stringify(items));
    if (disc > 0) audit(user, "discount", `sale #${no}: ${disc}`);
    db.exec("COMMIT");
    return saleOut(db.prepare("select * from sales where id=?").get(b.id), role);
  } catch (e) { db.exec("ROLLBACK"); throw e; }
}

// ---- HTTP ----
const readBody = req => new Promise((ok, no) => {
  let d = ""; req.on("data", c => { d += c; if (d.length > 1.2e6) { no(err(413, "Request too large")); req.destroy(); } });
  req.on("end", () => { try { ok(d ? JSON.parse(d) : {}); } catch { no(err(400, "Bad JSON")); } });
});
const send = (res, code, obj, extra = {}) => { res.writeHead(code, { "Content-Type": "application/json", "Cache-Control": "no-store", ...extra }); res.end(JSON.stringify(obj)); };
const needRole = (u, ...r) => { if (!r.includes(u.role)) throw err(403, "You do not have permission for this"); };

async function api(req, res, url) {
  const m = req.method, p = url.pathname;
  if (m === "GET" && p === "/api/users") return send(res, 200, { users: db.prepare("select name n, role from users order by rowid").all() });
  if (m === "POST" && p === "/api/login") {
    const b = await readBody(req), key = req.socket.remoteAddress + "|" + b.user; checkLock(key);
    const u = db.prepare("select * from users where name=?").get(String(b.user));
    if (!u || hashPin(b.pin, u.salt) !== u.hash) { noteFail(key); audit(b.user, "login-failed", req.socket.remoteAddress); throw err(401, "Wrong PIN. Try again."); }
    fails.delete(key); audit(u.name, "login", ""); return send(res, 200, { token: makeToken(u), user: { n: u.name, role: u.role } });
  }
  const me = auth(req);
  if (m === "GET" && p === "/api/data") {
    const sales = me.role === "cashier" ? [] : db.prepare("select * from sales order by no desc limit 5000").all().reverse().map(r => saleOut(r, me.role));
    return send(res, 200, { products: allProducts(me.role), sales, n: db.prepare("select coalesce(max(no),1000) n from sales").get().n });
  }
  if (m === "PUT" && p.startsWith("/api/products/")) {
    needRole(me, "owner", "manager"); saveProduct(decodeURIComponent(p.slice(14)), await readBody(req), me.n);
    return send(res, 200, { products: allProducts(me.role) });
  }
  if (m === "POST" && p === "/api/sales") {
    const sale = createSale(await readBody(req), me.n, me.role);
    return send(res, 200, { sale, products: allProducts(me.role) });
  }
  if (m === "POST" && p === "/api/pin") {
    const b = await readBody(req); if (!/^\d{4,6}$/.test(String(b.pin))) throw err(400, "PIN must be 4 to 6 digits");
    const salt = crypto.randomBytes(16).toString("hex");
    db.prepare("update users set salt=?,hash=? where name=?").run(salt, hashPin(b.pin, salt), me.n); audit(me.n, "pin-change", ""); return send(res, 200, { ok: true });
  }
  if (m === "GET" && p === "/api/backup") {
    needRole(me, "owner");
    return send(res, 200, { exported: new Date().toISOString(), products: db.prepare("select * from products").all(), sales: db.prepare("select * from sales").all(), audit: db.prepare("select * from audit").all() },
      { "Content-Disposition": `attachment; filename="nexra-backup-${new Date().toISOString().slice(0, 10)}.json"` });
  }
  throw err(404, "Not found");
}

const MIME = { ".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "text/javascript", ".png": "image/png", ".jpg": "image/jpeg", ".svg": "image/svg+xml", ".ico": "image/x-icon" };
http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://x");
  try {
    if (url.pathname.startsWith("/api/")) return await api(req, res, url);
    const f = path.join(__dirname, "public", url.pathname === "/" ? "index.html" : path.normalize(url.pathname));
    if (!f.startsWith(path.join(__dirname, "public")) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) throw err(404, "Not found");
    res.writeHead(200, { "Content-Type": MIME[path.extname(f)] || "application/octet-stream", "X-Content-Type-Options": "nosniff" });
    fs.createReadStream(f).pipe(res);
  } catch (e) {
    if (!(e instanceof HttpError)) console.error(e);
    send(res, e.status || 500, { error: e.status ? e.message : "Server error" });
  }
}).listen(PORT, () => console.log("Nexra POS running on http://localhost:" + PORT));
