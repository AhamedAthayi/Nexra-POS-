# Nexra Vegetable Shop POS - with backend database

Node.js server + SQLite database. No npm install needed (needs Node 22.13 or newer).

## Run on your computer
    npm start
Open http://localhost:3000 on the same network from a phone using the computer's IP address.

## Put it online (Render.com example)
1. Upload this folder to a GitHub repository.
2. Render > New > Web Service > pick the repo. Runtime: Node. Build command: (empty). Start command: `npm start`.
3. Add a Disk (mount path `/data`) and set environment variable `DB_PATH=/data/nexra.db` so sales are not lost on restart.
4. Open the https address Render gives you on the shop phones.

## First login
Owner 1111, Manager 2222, Cashier 3333. Change every PIN straight away (tap your name at the top > Save PIN).

## What the server does
- PINs are stored hashed. Login gives a 12-hour token. 5 wrong PINs lock that user for 5 minutes.
- Prices, totals and stock are calculated on the server, so a phone cannot fake them.
- Retrying a sale (bad network) never creates a second sale.
- Cashier: can sell only, no costs or history. Manager: products and reports. Owner: also backup.
- Audit table records logins, price/stock changes, discounts, PIN changes.

## Backup (Owner)
    curl -s -X POST localhost:3000/api/login -H "Content-Type: application/json" -d '{"user":"Owner","pin":"YOUR_PIN"}'
    curl -H "Authorization: Bearer TOKEN" localhost:3000/api/backup -o backup.json
Also copy the `nexra.db` file regularly.

## Not included yet
Refunds, purchases/suppliers, expenses, and offline selling when the server is unreachable.
